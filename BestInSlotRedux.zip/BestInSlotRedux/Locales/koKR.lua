local L = LibStub("AceLocale-3.0"):NewLocale("BestInSlotRedux", "koKR")
if L then
--@localization(locale="koKR", format="lua_additive_table", escape-non-ascii="true", handle-unlocalized="ignore")@
end