local L = LibStub("AceLocale-3.0"):NewLocale("BestInSlotRedux", "zhCN")
if L then
--@localization(locale="zhCN", format="lua_additive_table", escape-non-ascii="true", handle-unlocalized="ignore")@
end