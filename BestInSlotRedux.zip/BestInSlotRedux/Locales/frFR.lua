local L = LibStub("AceLocale-3.0"):NewLocale("BestInSlotRedux", "frFR")
if L then
--@localization(locale="frFR", format="lua_additive_table", escape-non-ascii="true", handle-unlocalized="ignore")@
end