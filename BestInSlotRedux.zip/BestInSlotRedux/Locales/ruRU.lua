local L = LibStub("AceLocale-3.0"):NewLocale("BestInSlotRedux", "ruRU")
if L then
--@localization(locale="ruRU", format="lua_additive_table", escape-non-ascii="true", handle-unlocalized="ignore")@
end