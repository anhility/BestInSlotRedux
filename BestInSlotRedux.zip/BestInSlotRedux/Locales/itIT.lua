local L = LibStub("AceLocale-3.0"):NewLocale("BestInSlotRedux", "itIT")
if L then
--@localization(locale="itIT", format="lua_additive_table", escape-non-ascii="true", handle-unlocalized="ignore")@
end