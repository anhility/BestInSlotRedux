local L = LibStub("AceLocale-3.0"):NewLocale("BestInSlotRedux", "ptBR")
if L then
--@localization(locale="ptBR", format="lua_additive_table", escape-non-ascii="true", handle-unlocalized="ignore")@
end