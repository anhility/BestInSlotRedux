local L = LibStub("AceLocale-3.0"):NewLocale("BestInSlotRedux", "deDE")
if L then
--@localization(locale="deDE", format="lua_additive_table", escape-non-ascii="true", handle-unlocalized="ignore")@
end