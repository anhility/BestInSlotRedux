local NyahRaid = LibStub("AceAddon-3.0"):GetAddon("BestInSlotRedux"):NewModule("NyahRaid")
local Nyah = "Nyah"
function NyahRaid:OnEnable()
  local L = LibStub("AceLocale-3.0"):GetLocale("BestInSlotRedux")
  
  local nyahName = C_Map.GetMapInfo(1581).name
  self:RegisterExpansion("Battle for Azeroth", EXPANSION_NAME7)
  self:RegisterRaidTier("Battle for Azeroth", 80444, nyahName, PLAYER_DIFFICULTY1, PLAYER_DIFFICULTY2, PLAYER_DIFFICULTY6)
  self:RegisterRaidInstance(80444, Nyah, nyahName, {
    bonusids = {
      [1] = {3524},
      [2] = {3524},
      [3] = {3524}
    },
    difficultyconversion = {
      [1] = 3, --Raid Normal
      [2] = 5, --Raid Heroic
      [3] = 6, --Raid Mythic
    }
  })
  --------------------------------------------------
  ----- Ny'alotha, the Waking City
  --------------------------------------------------
  

  -----------------------------------
  ----- Wrathion, the Black Emperor
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2368)
  local lootTable = {
    174105, --Mish'un, Blade of Tyrants
    172185, --Destroyer's Shadowblade
    172199, --Faralos, Empire's Dream
    174170, --Dragonbone Vambraces
    174125, --Emberscale Gloves
    174153, --Ebony Scaled Gauntlets
    174139, --Onyx-Imbued Breeches
    174044, --Humming Black Dragonscale
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Maut
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2365)
  local lootTable = {
    172191, --An'zig Vra
    172200, --Sk'shuul Vaz
    174132, --Stygian Guise
    174152, --Pauldrons of Ill Portent
    174124, --Mana-Infused Sash
    174155, --Greaves of Forbidden Magics
    174172, --Living Obsidian Legguards
    174141, --Boots of Manifest Shadow
    173944, --Forbidden Obsidian Claw
    173940, --Sigil of Warding
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- The Prophet Skitra
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2369)
  local lootTable = {
    174279, --Encrypted Ny'alothan Text
    172201, --Bloodstained Ritual Athame
    172193, --Whispering Eldritch Bow
    174165, --Writhing Spaulders of Madness
    174119, --Robes of Unreality
    174138, --Bracers of Dark Prophecy
    174143, --Macabre Ritual Pants
    174123, --Psychic's Subtle Slippers
    174157, --Talons of Grim Revelations
    174173, --Boots of Hallucinatory Reality
    174060, --Psyche Shredder
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Dark Inquisitor Xanesh
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2377)
  local lootTable = {
    172196, --Vorzz Yoq'al
    172190, --NO NAME?
    174169, --Gauntlets of Foul Inquisition
    174140, --Cord of Anguished Cries
    174126, --Binding of Dark Heresies
    174156, --Chainlink Belt of Ill Omens
    174121, --Trousers of Peculiar Potency
    173943, --Torment in a Jar
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- The Hivemind
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2372)
  local lootTable = {
    174106, --Qwor N'lyeth
    172192, --The All-Seeing Eye
    174122, --Void-Drenched Wristwraps
    174154, --Nightmarish Chain Shackles
    174137, --Chitinspine Gloves
    174171, --Dark Crystalline Girdle
    174530, --Ring of Collective Consciousness
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Shad'har the Insatiable
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2367)
  local lootTable = {
    172186, --Warmace of Waking Nightmares
    174107, --Insidious Writhing Longbow
    174145, --Wristwraps of Volatile Power
    174177, --Bracers of Phantom Pains
    174162, --Ego-Annihilating Grips
    174130, --Grips of Occult Reminiscence
    174531, --Void-Etched Band
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Drest'agath
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2373)
  local lootTable = {
    172195, --Halsheth, Slumberer's Spear
    172198, --Mar'kowa, the Mindpiercer
    174146, --Gloves of Abyssal Authority
    174174, --Belt of Muttering Truths
    174159, --Spinebarb Legplates
    174532, --Ichorspine Loop
    173946, --Writhing Segment of Drest'agath
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Il'gynoth, Corruption Reborn
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2374)
  local lootTable = {
    172189, --Eyestalk of Il'gynoth
    172188, --NO NAME?
    174163, --Second Sight Helm
    174116, --Cowl of Unspeakable Horrors
    174135, --Spaulders of Aberrant Allure
    174150, --Scales of the Scheming Behemoth
    174161, --Bracers of Manifest Apathy
    174129, --Cuffs of Grim Conjuration
    174142, --Belt of Braided Vessels
    174176, --Sabatons of Malevolent Intent
    174180, --Oozing Coagulum
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Vexiona
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2370)
  local lootTable = {
    172194, --Gift of the Void
    174148, --Helm of Deep Despair
    174120, --Void Ascendant's Mantle
    174164, --Breastplate of Twilight Decimation
    174131, --Darkheart Robe
    174160, --Greaves of the Twilight Drake
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Ra-den the Despoiled
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2364)
  local lootTable = {
    172228, --Shandai, Watcher of Cosmos
    172197, --Unguent Caress
    174134, --Gibbering Maw
    174149, --Dreamer's Unblinking Pauldrons
    174168, --Carapace of Pulsing Vita
    174115, --Robe of the Fallen Keeper
    174175, --Reality-Defying Greaves
    174128, --Boots of Wrought Shadow
    174528, --Void-Twisted Titanshard
    174500, --Vita-Charged Titanshard
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- Carapace of N'Zoth
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2366)
  local lootTable = {
    174108, --Shgla'yos, Astral Malignity
    174109, --Lurker's Piercing Gaze
    172227, --Shard of the Black Empire
    174151, --Helm of Actualized Visions
    174166, --Pauldrons of Infinite Darkness
    174117, --Spaulders of Miasmic Mycelia
    174136, --Tortured Fleshbeast Cuirass
    174178, --Mirage-Weaver's Gauntlets
    174158, --Watcher's Scheming Girdle
    174127, --Corporeal Supplicant's Trousers
    174144, --Corpuscular Leather Greaves
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
  

  -----------------------------------
  ----- N'Zoth the Corruptor
  -----------------------------------
  local bossName = EJ_GetEncounterInfo(2375)
  local lootTable = {
    172187, --Devastation's Hour
    172229, --Dominion, Lurker Beyond Dreams
    174118, --Visage of Nightmarish Machinations
    174167, --Greathelm of Phantasmic Reality
    174133, --Pauldrons of the Great Convergence
    174147, --Last Vestige of Neltharion
    174533, --Ring of Cosmic Potential
    174277, --Lingering Psychic Shell
    174103, --Manifesto of Madness
  }
  self:RegisterBossLoot(Nyah, lootTable, bossName)
end
  

function NyahRaid:InitializeZoneDetect(ZoneDetect)
  ZoneDetect:RegisterMapID(1581, Nyah)
  ZoneDetect:RegisterNPCID(156818, Nyah, 1) --Wrathion, the Black Emperor
  ZoneDetect:RegisterNPCID(156523, Nyah, 2) --Maut
  ZoneDetect:RegisterNPCID(161901, Nyah, 3) --The Prophet Skitra
  ZoneDetect:RegisterNPCID(160229, Nyah, 4) --Dark Inquisitor Xanesh
  ZoneDetect:RegisterNPCID(157253, Nyah, 5) --The Hivemind
  ZoneDetect:RegisterNPCID(157231, Nyah, 6) --Shad'har the Insatiable
  ZoneDetect:RegisterNPCID(157602, Nyah, 7) --Drest'agath
  ZoneDetect:RegisterNPCID(158328, Nyah, 8) --Il'gynoth, Corruption Reborn
  ZoneDetect:RegisterNPCID(157354, Nyah, 9) --Vexiona
  ZoneDetect:RegisterNPCID(156866, Nyah, 10) --Ra-den the Despoiled
  ZoneDetect:RegisterNPCID(157439, Nyah, 11) --Carapace of N'Zoth
  ZoneDetect:RegisterNPCID(158041, Nyah, 12) --N'Zoth the Corruptor
end